from django.apps import AppConfig


class AcademicoConfig(AppConfig):
    name = 'Academico'
